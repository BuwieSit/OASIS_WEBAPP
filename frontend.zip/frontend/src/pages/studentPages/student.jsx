
import { Link } from 'react-router-dom'
import { useEffect, useState } from "react";
import { getStudentDashboardHTEs } from "../../api/studentDashboard.service";
import MainScreen from '../../layouts/mainScreen';
import fallbackImg from "../../assets/fallbackImage.jpg"
import { UpperWave, LowerWave } from '../../utilities/waves';
import Title from '../../utilities/title';
import Subtitle from '../../utilities/subtitle';
import { CustomCard, TutorialCard } from '../../utilities/card';
import { StudentTable } from '../../components/oasisTable';
import { Text, StatusView, ViewMoaButton } from '../../utilities/tableUtil';
import SearchBar from '../../components/searchBar';
import { Filter } from '../../components/adminComps';
import { FilterIcon } from 'lucide-react';
import { ViewModal } from '../../components/popupModal';
import filePdf from "../../assets/resume.pdf";
import PdfViewer from '../../utilities/pdfViewer';

export default function Student() {

    const [tableData, setTableData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState("");

    useEffect(() => {
        getStudentDashboardHTEs({ search })
            .then((htes) => {
                const mappedData = htes.map(hte => ({
                    id: hte.id,
                    hteName: hte.name,
                    industry: hte.industry,
                    signedDate: hte.moa_signed_at || "—",
                    expiryDate: hte.moa_expiry_date || "—",
                    moaStatus: hte.moa_status,
                    moaUrl: hte.moa_file
                        ? `${import.meta.env.VITE_API_URL}/api/student/htes/${hte.id}/moa`
                        : null
                }));

                setTableData(mappedData);
            })
            .catch((err) => {
                console.error("Failed to load HTE dashboard data", err);
            })
            .finally(() => {
                setLoading(false);
            });
    }, [search]);
    
    const columns = [
        {header: "HTE Name", render: row => <Text text={row.hteName}/>},
        {header: "Nature of Business", render: row => <Text text={row.industry}/>},
        {header: "MOA Signed Date", render: row => <Text text={row.signedDate}/>},
        {header: "MOA Expiration", render: row => <Text text={row.expiryDate}/>},
        {header: "MOA Status", render: row => <StatusView value={row.moaStatus}/>},
        {
            header: "MOA File",
            render: row => (
                <ViewMoaButton
                    onClick={() => handleDownloadMOA(row.id)}
                />
            )
        }
    ]

    
    const handleDownloadMOA = async (hteId) => {
        try {
            const res = await downloadMOA(hteId);

            const url = window.URL.createObjectURL(new Blob([res.data]));
            const link = document.createElement("a");
            link.href = url;
            link.setAttribute("download", `HTE_${hteId}_MOA.pdf`);
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (err) {
            console.error("Failed to download MOA", err);
        }
    };

    const [openView, setOpenView] = useState(false);

    return(
        <>
            <MainScreen hasTopMargin={true}>
                
                <ViewModal 
                    visible={openView}
                    onClose={() => setOpenView(false)}
                    isDocument={true}
                    file={filePdf}
                    resourceTitle="Buwie Resume"
                />
                <div className="w-[90%] aspect-video rounded-3xl overflow-hidden relative flex flex-col items-center justify-center shadow-[0px_0px_10px_rgba(0,0,0,1)]">

                    <section className='w-full flex flex-col justify-center items-center'>
                        <h1 className='sm:text-5xl md:text-6xl lg:text-8xl font-oasis-text font-bold bg-oasis-gradient bg-clip-text text-transparent  text-center z-5 drop-shadow-[5px_5px_5px_rgba(255,255,255,0.5)]'>Welcome to OASIS</h1>
                   
                        <p className='sm:text-[0.9rem] md:text-[1rem] lg:text-[1.2rem] italic font-oasis-text font-bold text-white text-shadow-[0px_2px_5px_rgba(255,255,255,0.5)] text-center z-5'>Tulay sa oportunidad, gabay sa kinabukasan</p>
                    </section>
                     
                     
                     <button className='sm:w-50 md:w-60 lg:w-70 px-10 absolute top-[75%] left-1/2 -translate-x-1/2 -translate-y-1/2 py-4 rounded-2xl text-center bg-linear-to-b from-oasis-button-light to-oasis-blue to-110% z-5 text-oasis-button-dark font-bold font-oasis-text cursor-pointer shadow-[2px_2px_2px_rgba(0,0,0,0.5)] duration-100 transition ease-in-out hover:scale-115 hover:from-oasis-button-light hover:to-oasis-button-light hover:text-white'><a href="#prospectForm">Submit MOA Prospect</a></button>

                    <img src={fallbackImg} className='absolute w-full h-full mt-[-20] object-cover bg-center bg-no-repeat bg-cover opacity-70'/>
                   
                </div>

                {/* <UpperWave/> */}
                <div className='w-full min-h-150 mt-20 h-auto pb-5 pt-5 flex flex-wrap flex-col items-center justify-center gap-10'>

                    <section className='w-[50%] flex flex-col gap-2'>
                        <Title text="HTE Dashboard Updates"/>
                        <Subtitle isCenter={true} size={'text-[0.9rem]'} text="See the latest HTEs with updates regarding their MOA status!"/>
                    </section>

                    {/* TABLE HERE */}
                    <StudentTable columns={columns} data={tableData}>
                        <div className='w-full flex flex-row justify-between items-center'>
                            <SearchBar
                                value={search}
                                onChange={setSearch}
                            />
                        </div>
                        
                    </StudentTable>

                    <section className='w-[50%] flex flex-col gap-2 mt-10'>
                        <Title text="What is OASIS?"/>
                        <Subtitle isCenter={true} size={'text-[0.9rem]'} text="OJT Administration Support, and Information System is your all-in-one platform for managing OJT requirements, announcements, and host establishment information. Explore the cards below to learn more!"/>
                    </section>
                   

                    <div className="w-[80%] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 pt-10 pb-10 justify-center place-items-center">

                        <TutorialCard onClick={() => setOpenView(true)}/>
                        <TutorialCard onClick={() => setOpenView(true)}/>
                        <TutorialCard onClick={() => setOpenView(true)}/>
                        <TutorialCard onClick={() => setOpenView(true)}/>
                        
                    </div>
                </div>
                {/* <LowerWave/> */}


            </MainScreen>          
        </>
    )
}