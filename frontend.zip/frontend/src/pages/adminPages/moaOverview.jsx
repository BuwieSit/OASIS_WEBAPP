import AdminScreen from '../../layouts/adminScreen.jsx';
import { AdminHeader } from '../../components/headers.jsx'
import Title from "../../utilities/title.jsx";
import OasisTable from '../../components/oasisTable.jsx';
import {
    Text,
    HteLocation,
    StatusDropdown,
    ActionButtons,
    ViewMoaButton
} from "../../utilities/tableUtil.jsx";
import useQueryParam from '../../hooks/useQueryParams.jsx';
import { useState } from 'react';
import { Filter } from '../../components/adminComps.jsx';
import Subtitle from '../../utilities/subtitle.jsx';

export default function MoaOverview() {

    const [activeFilter, setFilter] = useQueryParam("tab", "overview");

    const currentMoaColumns = [
        { header: "HTE Name", render: row => <Text text={row.hteName} /> },
        { header: "Industry", render: row => <Text text={row.industry} /> },
        { header: "Location", render: row => <HteLocation address={row.location} /> },
        { header: "Contact Person", render: row => <Text text={row.contactPerson} /> },
        { header: "Expiry Date", render: row => <Text text={row.expiryDate} /> },
        { header: "MOA Status", render: row => <StatusDropdown value={row.status} /> },
        { header: "Actions", render: row => <ActionButtons rowId={row.id} /> }
    ];
    // MOCK DATA
    const currentMoasData = [
        {
            id: 1,
            hteName: "KSILVER Inc.",
            industry: "IT Services",
            location: "Quezon City",
            contactPerson: "Juan Dela Cruz",
            expiryDate: "Dec 12, 2026",
        }
    ];

    const prospectMoaColumns = [
        { header: "HTE Name", render: row => <Text text={row.hteName} /> },
        { header: "Industry", render: row => <Text text={row.industry} /> },
        { header: "Location", render: row => <HteLocation address={row.location} /> },
        { header: "Contact Person", render: row => <Text text={row.contactPerson} /> },
        { header: "Contact Number", render: row => <Text text={row.contactNumber} /> },
        { header: "MOA File", render: row => <ViewMoaButton url={row.moaFile} /> },
        { header: "Actions", render: row => <ActionButtons rowId={row.id} /> }
    ];
// MOCK DATA
    const prospectMoaData = [
        {
            id: 1,
            hteName: "KSILVER Inc.",
            industry: "IT Services",
            location: "Quezon City",
            contactPerson: "Juan Dela Cruz",
            contactPerson: "Bogart Rodriguez",
            contactNumber: "09512362344",
            moaFile: "www.youtube.com"
        }
    ];
  
    return(
        <>
            <AdminScreen>
                <div className='flex flex-row gap-3 w-[80%]'>
                    
                    <Subtitle 
                        text={"MOA Overview"}
                        onClick={() => setFilter("overview")}
                        isActive={activeFilter === "overview"}
                        isLink={true}
                        size='text-[1rem]'
                    />
                    <Subtitle text={"|"} size='text-[1rem]'/>
                    <Subtitle 
                        text={"MOA Prospect Submissions"}
                        onClick={() => setFilter("submissions")}
                        isActive={activeFilter === "submissions"}
                        isLink={true}
                        size='text-[1rem]'
                    />
                </div>
               
                {activeFilter === "overview" && 
                    <>
                        <div className='flex justify-start items-start w-[80%]'>
                            <Title text={"MOA Overview"}/>
                        </div>
                        <OasisTable columns={currentMoaColumns} data={currentMoasData}/>
                    </>
                }
                {activeFilter === "submissions" &&
                    <>
                        <div className='flex justify-start items-start w-[80%]'>
                            <Title text={"MOA Prospects Submissions"}/>
                        </div>

                        <OasisTable columns={prospectMoaColumns} data={prospectMoaData}/>
                    </>
                }
            </AdminScreen>
        </>
    )
}