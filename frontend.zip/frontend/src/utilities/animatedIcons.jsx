import check from "../assets/icons/check.gif"

export function CheckIcon() {
    return (
        <>
            <img src={check}/>
        </>
    )
}
